# plenticons

A library of icons for your custom nodes!

See more on [Github].

[Github]: https://github.com/foxssake/plenticons
